package cn.example02;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import javax.jws.soap.SOAPBinding;
import java.io.IOException;
import java.io.PrintWriter;

public class LoginServlet extends HttpServlet {
    public void doGet (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=utf-8");
        String username =req.getParameter("username");
        String password =req.getParameter("password");
        String checkcode =req.getParameter("check_code");
        String saveCode = (String)req.getSession().getAttribute("check_code");
        PrintWriter pw = resp.getWriter();
        //假设正确的用户名是itcast 密码是123
        if (("itcast").equals(username) && ("123").equals(password)&& checkcode.equals(saveCode)) {
            User user =new User();
            user.setUsername(username);
            user.setPassword(password);
            req.getSession().setAttribute("user",user);
            resp.sendRedirect("/lianxi01/IndexServlet");

        }
        else if (checkcode.equals(saveCode)){
            pw.write("用户名或密码错误，登录失败");
        }else {
            pw.write("验证码错误");
        }
    }
    public  void doPost (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
}
