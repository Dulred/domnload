package cn.example02;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

import java.io.IOException;

//显示网站的首页面
public class IndexServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    public void doGet (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //解决乱码问题
        resp.setContentType("text/html;charset=utf-8");
        //创建或者获取保存用户信息的Session对象
        HttpSession session = req.getSession();
        User user = (User)session.getAttribute("user");
        if (user==null){
            resp.getWriter().print("您还没有登录，请<a href='/lianxi01/login.html'>登录</a>");

        }else {
            resp.getWriter().print("您已登录，欢迎您," +user.getUsername()+"!");
            resp.getWriter().print(
                    "<a href = '/lianxi01/LogoutServlet'>退出</a>"
            );
            //创建Cookie存放Session的标识号
            Cookie cookie =new Cookie("JSESSIONID",session.getId());
            cookie.setMaxAge(60*30);
            cookie.setPath("/lianxi01");
            resp.addCookie(cookie);
        }
    }
    public void doPost (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
}
