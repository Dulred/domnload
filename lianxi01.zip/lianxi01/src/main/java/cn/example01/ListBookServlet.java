package cn.example01;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

//显示所有可购买图书的列表
public class ListBookServlet extends HttpServlet {
        private static final long serialVersionUID = 1L;
        public void doGet (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
            resp.setContentType("text/html;charset=utf-8");
            PrintWriter out = resp.getWriter();
            Collection<Book> books = BookDB.getAll();
            out.write("本站提供的图书有: <br />");
            for(Book book : books){
                String url = "/lianxi01/PurchaseServlet?id=" + book.getId();
                HttpSession s =req.getSession();
                String newurl = resp.encodeRedirectURL(url);
                out.write(book.getName() + "<a href = '" + newurl + "' > 点击购买</a><br/>");
            }
        }
}
